[English](README.md) | Russian | [Czech](README-CZ.md) | [Spanish](README-ES.md) | [简体中文](README-CN.md)

**Translation was made by @SergeyMC9730**

# GD-Decompiled
 Попытка получить исходники кода для Geometry Dash через обратную инженерию и декомпиляцию игры

## ВАЖНО

- Данный Проект является справкой, связанной с моддингом.
- Данный репозиторий <b>не является</b> точной декомпиляцией
- Так как код нельзя скомпилировать, то и в синтаксисе могут быть также ошибки.

Классы, которые были начаты, но ещё не завершены, могут быть найдены в
[Проблемах](https://github.com/Wyliemaster/GD-Decompiled/issues).

## Купить ГД

если по какой-либо причине у вас ещё нет её, то я рекомендую взять и купить ГД

- [Android](https://play.google.com/store/apps/details?id=com.robtopx.geometryjump&hl=en_GB&gl=US)
- [IOS](https://apps.apple.com/us/app/geometry-dash/id625334537)
- [windows/mac](https://store.steampowered.com/app/322170/Geometry_Dash/)

## хочешь больше знать об этой игре?

если ты хочешь знать об этой игре и как работают различные его аспекты, ты можешь найти *не переведённую* документацию [здесь](https://github.com/Wyliemaster/gddocs)