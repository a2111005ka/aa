[English](README.md) | [Russian](README-RU.md) | [Czech](README-CZ.md) | Spanish | [简体中文](README-CN.md)

# GD Decompiled

This translation was made by: @Adrikikicp

Este es el intento de decompilación de Geometry Dash 2.113

Importante:

Este código es para propósito educativo, y una referencia

El código no es compilable

Como el código no es compilable, pueden haber errores de sintáxis


# Compra GD

Porfa no uses las versiones crackeadas de Geometry Dash. Puedes comprarlo aquí:

[[Windows y Mac]](https://store.steampowered.com/app/322170/Geometry_Dash/)
[[Android]](https://play.google.com/store/apps/details?id=com.robtopx.geometryjump)
[[iOS]](https://apps.apple.com/us/app/geometry-dash/id625334537)



# Documentación

Puedes ver el siguiente repositorio que puede ayudar un poco a aprender qué clases hay en Geometry Dash 
[aquí](https://github.com/Wyliemaster/gd.docs)
