#include "includes.h"

class ListCell : public TableViewCell
{
	cocos2d::ccColor4B m_cLine;
};
