#include "includes.h"

class GameCell : public TableViewCell
{
	void* m_pUnk; // cant find any xrefs
	std::string m_sEndpoint;
};
