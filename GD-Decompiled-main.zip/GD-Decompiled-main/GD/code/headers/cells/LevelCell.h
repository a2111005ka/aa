#include "includes.h"

class LevelCell : public TableViewCell
{
	CCMenuItemSpriteExtra* m_pBtn;
	GJGameLevel* m_pLevel;
	bool m_bCellDrawn;
};
