#include "includes.h"

class GJScoreCell : public TableViewCell, public FLAlertLayerProtocol
{
	GJUserScore* m_pScore;
};
