#include "includes.h"

class ArtistCell : public TableViewCell
{
	SongInfoObject* m_pSong;
};
