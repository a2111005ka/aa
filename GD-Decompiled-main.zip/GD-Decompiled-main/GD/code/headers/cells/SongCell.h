#include "includes.h"

class SongCell : public TableViewCell
{
	SongObject* m_pSong;
};

