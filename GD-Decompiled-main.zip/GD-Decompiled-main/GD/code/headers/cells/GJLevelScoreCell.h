#include "includes.h"

class GJLevelScoreCell : public TableViewCell
{
	GJUserScore* m_pScore;
};
