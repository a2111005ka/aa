#include "includes.h"

class CustomSongCell : public TableViewCell
{
	SongInfoObject* m_pSong;
};
