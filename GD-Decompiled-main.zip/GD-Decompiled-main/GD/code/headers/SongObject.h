#include "includes.h"

class SongObject : public cocos2d::CCObject
{
	int m_nIdx;
};
