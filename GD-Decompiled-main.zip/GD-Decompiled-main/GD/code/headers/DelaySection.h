#include "includes.h"

class DelaySection : cocos2d::CCObject
{
	int m_nStart;
	float m_fDelay;
};
