#include "includes.h"

class ColoredSection : cocos2d::CCObject
{
	cocos2d::ccColor3B m_cColour;
	int m_nStart;
	int m_nEnd;
};
