#include "includes.h"

class InstantSection : cocos2d::CCObject
{
	int m_nStart;
	int m_nEnd;
};
