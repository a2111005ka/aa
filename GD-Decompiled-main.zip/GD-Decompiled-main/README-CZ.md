[English](README.md) | [Russian](README-RU.md) | Czech | [Spanish](README-ES.md) | [简体中文](README-CN.md)

**Translation was made by @Cvolton** ***[OUTDATED!!]***

# GD-Dekompilováno
 snaha získat zdrojový kód ke hře Geometry Dash za pomocí reverzního inženýrství a dekompilování hry.  

- Má sloužit jako reference. Nelze zkompilovat

## Koupit GD

pokud už jste tak z nějakého důvodu neučinili, doporučuji vám jít si koupit GD

- [Android](https://play.google.com/store/apps/details?id=com.robtopx.geometryjump&hl=en_GB&gl=US)
- [IOS](https://apps.apple.com/us/app/geometry-dash/id625334537)
- [windows/mac](https://store.steampowered.com/app/322170/Geometry_Dash/)

## DŮLEŽITÉ

Tento repozitář se může změnit každou chvíli. Rozhodně není doporučováno jej využívat k čemukoliv, protože je ještě v počátcích. ~~A pak tady je taky to, že absolutně netuším co to vlastně dělám.~~  

Třídy, které jsem přidal, ale ještě nedokončil, můžete najít v [Issues](https://github.com/Wyliemaster/GD-Decompiled/issues).

## chcete vědět více o hře?

jestli chcete vědět více o hře a jak tam různé věci fungují, [zde](https://github.com/Wyliemaster/gddocs) můžete najít dokumentaci
